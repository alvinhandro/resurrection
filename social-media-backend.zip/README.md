# Social Media Backend

This is the backend for Alvin's social media app.

Run `npm install` and `node app.js` to start the server.